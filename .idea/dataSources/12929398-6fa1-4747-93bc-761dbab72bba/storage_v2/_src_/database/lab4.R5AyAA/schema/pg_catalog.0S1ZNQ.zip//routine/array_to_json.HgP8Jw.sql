create function array_to_json(anyarray) returns json
    language internal
as
$$array_to_json$$;

comment on function array_to_json(anyarray, bool) is 'map array to json with optional pretty printing';

