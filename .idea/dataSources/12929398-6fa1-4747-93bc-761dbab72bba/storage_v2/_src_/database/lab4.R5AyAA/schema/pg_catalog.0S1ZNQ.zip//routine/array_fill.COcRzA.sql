create function array_fill(anyelement, integer[]) returns anyarray
    language internal
as
$$array_fill$$;

comment on function array_fill(anyelement, _int4, _int4) is 'array constructor with value';

