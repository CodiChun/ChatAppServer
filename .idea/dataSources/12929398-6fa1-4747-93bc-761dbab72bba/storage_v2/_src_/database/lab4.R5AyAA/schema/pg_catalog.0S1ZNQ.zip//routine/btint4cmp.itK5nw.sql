create function btint4cmp(integer, integer) returns integer
    language internal
as
$$btint4cmp$$;

comment on function btint4cmp(int4, int4) is 'less-equal-greater';

