create function circle_overright(circle, circle) returns boolean
    language internal
as
$$circle_overright$$;

comment on function circle_overright(circle, circle) is 'implementation of &> operator';

