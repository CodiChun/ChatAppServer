create function bittypmodin(cstring[]) returns integer
    language internal
as
$$bittypmodin$$;

comment on function bittypmodin(_cstring) is 'I/O typmod';

