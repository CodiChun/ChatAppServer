create function bitgt(bit, bit) returns boolean
    language internal
as
$$bitgt$$;

comment on function bitgt(bit, bit) is 'implementation of > operator';

