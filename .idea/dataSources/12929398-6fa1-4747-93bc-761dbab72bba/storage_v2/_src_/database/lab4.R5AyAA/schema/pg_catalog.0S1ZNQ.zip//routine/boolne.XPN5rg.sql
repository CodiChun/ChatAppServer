create function boolne(boolean, boolean) returns boolean
    language internal
as
$$boolne$$;

comment on function boolne(bool, bool) is 'implementation of <> operator';

