create function cash_mul_flt8(money, double precision) returns money
    language internal
as
$$cash_mul_flt8$$;

comment on function cash_mul_flt8(money, float8) is 'implementation of * operator';

