create function bpcharlike(character, text) returns boolean
    language internal
as
$$textlike$$;

comment on function bpcharlike(bpchar, text) is 'implementation of ~~ operator';

