create function anycompatiblemultirange_out(anycompatiblemultirange) returns cstring
    language internal
as
$$anycompatiblemultirange_out$$;

comment on function anycompatiblemultirange_out(anycompatiblemultirange) is 'I/O';

