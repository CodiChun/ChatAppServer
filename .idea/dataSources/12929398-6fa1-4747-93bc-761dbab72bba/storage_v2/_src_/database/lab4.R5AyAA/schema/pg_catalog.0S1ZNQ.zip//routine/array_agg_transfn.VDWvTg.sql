create function array_agg_transfn(internal, anynonarray) returns internal
    language internal
as
$$array_agg_transfn$$;

comment on function array_agg_transfn(internal, anynonarray) is 'aggregate transition function';

