create function aclitemeq(aclitem, aclitem) returns boolean
    language internal
as
$$aclitem_eq$$;

comment on function aclitemeq(aclitem, aclitem) is 'implementation of = operator';

