create function btrim(text, text) returns text
    language internal
as
$$btrim$$;

comment on function btrim(bytea, bytea) is 'trim selected bytes from both ends of string';

