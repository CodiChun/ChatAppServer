create function cash_ge(money, money) returns boolean
    language internal
as
$$cash_ge$$;

comment on function cash_ge(money, money) is 'implementation of >= operator';

