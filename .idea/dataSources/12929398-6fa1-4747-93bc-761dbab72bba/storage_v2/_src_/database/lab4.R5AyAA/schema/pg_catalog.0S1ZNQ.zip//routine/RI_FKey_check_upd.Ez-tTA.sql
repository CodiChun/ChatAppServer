create function "RI_FKey_check_upd"() returns trigger
    language internal
as
$$RI_FKey_check_upd$$;

comment on function "RI_FKey_check_upd"() is 'referential integrity FOREIGN KEY ... REFERENCES';

