create function cstring_in(cstring) returns cstring
    language internal
as
$$cstring_in$$;

comment on function cstring_in(cstring) is 'I/O';

