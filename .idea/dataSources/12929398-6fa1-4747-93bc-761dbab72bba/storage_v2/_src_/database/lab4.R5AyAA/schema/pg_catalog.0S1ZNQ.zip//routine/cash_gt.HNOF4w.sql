create function cash_gt(money, money) returns boolean
    language internal
as
$$cash_gt$$;

comment on function cash_gt(money, money) is 'implementation of > operator';

