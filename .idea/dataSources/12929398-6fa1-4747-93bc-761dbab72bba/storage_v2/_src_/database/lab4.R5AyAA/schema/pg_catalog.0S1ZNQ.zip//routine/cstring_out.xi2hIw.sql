create function cstring_out(cstring) returns cstring
    language internal
as
$$cstring_out$$;

comment on function cstring_out(cstring) is 'I/O';

