create function _pg_char_octet_length(typid oid, typmod integer) returns integer
    language sql
as
$$$$;

