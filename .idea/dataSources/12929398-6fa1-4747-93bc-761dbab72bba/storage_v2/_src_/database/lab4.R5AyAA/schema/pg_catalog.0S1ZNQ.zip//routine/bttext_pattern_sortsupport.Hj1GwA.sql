create function bttext_pattern_sortsupport(internal) returns void
    language internal
as
$$bttext_pattern_sortsupport$$;

comment on function bttext_pattern_sortsupport(internal) is 'sort support';

