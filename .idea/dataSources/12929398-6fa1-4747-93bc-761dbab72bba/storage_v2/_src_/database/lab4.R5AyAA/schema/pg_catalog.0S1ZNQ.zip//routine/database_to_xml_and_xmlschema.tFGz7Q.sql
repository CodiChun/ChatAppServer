create function database_to_xml_and_xmlschema(nulls boolean, tableforest boolean, targetns text) returns xml
    language internal
as
$$database_to_xml_and_xmlschema$$;

comment on function database_to_xml_and_xmlschema(bool, bool, text) is 'map database contents and structure to XML and XML Schema';

