create function contsel(internal, oid, internal, integer) returns double precision
    language internal
as
$$contsel$$;

comment on function contsel(internal, oid, internal, int4) is 'restriction selectivity for containment comparison operators';

