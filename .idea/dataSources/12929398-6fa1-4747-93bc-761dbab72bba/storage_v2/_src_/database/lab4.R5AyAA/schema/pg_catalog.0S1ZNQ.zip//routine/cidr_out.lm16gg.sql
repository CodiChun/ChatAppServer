create function cidr_out(cidr) returns cstring
    language internal
as
$$cidr_out$$;

comment on function cidr_out(cidr) is 'I/O';

