create function bit_length(bit) returns integer
    language sql
as
$$$$;

comment on function bit_length(bit) is 'length in bits';

