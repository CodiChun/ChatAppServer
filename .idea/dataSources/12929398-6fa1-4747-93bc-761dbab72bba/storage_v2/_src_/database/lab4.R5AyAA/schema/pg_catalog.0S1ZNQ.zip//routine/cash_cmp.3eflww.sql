create function cash_cmp(money, money) returns integer
    language internal
as
$$cash_cmp$$;

comment on function cash_cmp(money, money) is 'less-equal-greater';

