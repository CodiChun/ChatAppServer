create function col_description(oid, integer) returns text
    language sql
as
$$$$;

comment on function col_description(oid, int4) is 'get description for table column';

