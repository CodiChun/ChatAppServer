create function brin_minmax_multi_summary_send(pg_brin_minmax_multi_summary) returns bytea
    language internal
as
$$brin_minmax_multi_summary_send$$;

comment on function brin_minmax_multi_summary_send(pg_brin_minmax_multi_summary) is 'I/O';

